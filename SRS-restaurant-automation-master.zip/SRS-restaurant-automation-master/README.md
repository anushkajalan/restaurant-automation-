# restaurant-automation
A document that includes various data flow diagrams describing the requirements of a Restaurant Automation System and the flow of data through the system.
Includes both static (ER, DFD) and dynamic diagrams(STD, UFD, FDD, etc.)
